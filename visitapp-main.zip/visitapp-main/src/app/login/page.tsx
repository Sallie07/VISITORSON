
import React from "react";
import Login from "@/components/login/login";
import Layout from "@/components/layout";
const LoginPage = () => {
  return (
    <div className=" min-h-screen">
      <Login />
    </div>
  );
};
export default LoginPage;