"use client"
import React from "react";
import Layout from "@/components/layout";
import Userregistration from "@/components/Userregistration/Userregistration";

const MakeClaimPage = () => {
  return (

    <div >
      <Layout>
        <Userregistration />
      </Layout>
    </div>

  );
};

export default MakeClaimPage;

